from .brain_games import brain_even
from engine import starting_the_game
def main():
    starting_the_game(brain_even)