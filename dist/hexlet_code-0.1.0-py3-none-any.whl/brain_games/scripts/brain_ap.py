from brain_games.engine import starting_the_game
from brain_games.games import brain_ap


DESCRIPTION = 'What number is missing in the progression?'


def main():
    starting_the_game(brain_ap)


if __name__ == '__main__':
    main()